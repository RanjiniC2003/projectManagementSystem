package common;

import java.sql.Connection;

public class Application{

	public static Connection dbConnection;
}

